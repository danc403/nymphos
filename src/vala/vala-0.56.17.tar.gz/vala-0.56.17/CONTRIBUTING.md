Please read our wiki page [Documentation for Contributors to Vala](https://wiki.gnome.org/Projects/Vala/DeveloperDocumentation)
