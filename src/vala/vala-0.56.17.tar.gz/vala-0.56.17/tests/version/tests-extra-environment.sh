export PKG_CONFIG_PATH=$abs_srcdir/version
