VALAFLAGS="--enable-experimental-non-null"
