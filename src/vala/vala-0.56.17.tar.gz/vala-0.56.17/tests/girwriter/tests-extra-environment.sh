VALAFLAGS="--vapidir ${abs_srcdir}/girwriter"
