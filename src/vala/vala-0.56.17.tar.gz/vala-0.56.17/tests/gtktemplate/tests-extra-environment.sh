PACKAGES="gtk+-3.0"
VALAFLAGS="--gresources ${abs_srcdir}/gtktemplate/gtktemplate.gresource.xml"
