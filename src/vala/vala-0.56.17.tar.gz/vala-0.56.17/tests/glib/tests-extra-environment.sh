VALAFLAGS="--target-glib=auto"
