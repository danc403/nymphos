Security Policy
=========================

To report security vulnerabilities, please follow our special [security policy](https://mariadb.org/about/security-policy/). **Do not** report security issues in the public issue tracker.
