DeLiMiTeR A;
SELECT 1 A;
delimiter ;
