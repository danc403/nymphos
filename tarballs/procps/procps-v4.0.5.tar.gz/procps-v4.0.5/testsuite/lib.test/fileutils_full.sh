#!/bin/sh

${PWD}/../src/tests/test_fileutils > /dev/full
