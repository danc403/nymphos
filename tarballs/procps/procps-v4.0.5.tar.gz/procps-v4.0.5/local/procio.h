#ifndef PROCPS_PROC_PROCIO_H
#define PROCPS_PROC_PROCIO_H

FILE *fprocopen(const char *path, const char *mode);

#endif
