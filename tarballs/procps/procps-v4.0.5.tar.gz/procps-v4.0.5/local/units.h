#ifndef PROCPS_UNITS_H
#define PROCPS_UNITS_H

const char* scale_size(unsigned long size, unsigned int exponent, int si, int humanreadable);

#endif
