#ifndef PHP_DB2_H
#define PHP_DB2_H

#ifdef DBA_DB2

#include "php_dba.h"

DBA_FUNCS(db2);

#endif

#endif
