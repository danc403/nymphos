Code of Conduct
===

GLib follows the GNOME Code of Conduct, which is documented here:
https://conduct.gnome.org/
