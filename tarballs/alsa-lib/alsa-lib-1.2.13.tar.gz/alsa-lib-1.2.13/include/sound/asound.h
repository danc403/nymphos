/* workaround for building with old glibc / kernel headers */
#include <alsa/sound/type_compat.h>

#include <alsa/sound/uapi/asound.h>
