// This is created by autoconf on POSIX-compatibe build environments.
#define PACKAGE_VERSION "1.52.0"
