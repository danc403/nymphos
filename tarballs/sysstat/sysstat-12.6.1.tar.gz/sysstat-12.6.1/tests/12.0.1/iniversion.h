/*
 * sysstat: System performance tools for Linux
 * (C) 1999-2018 by Sebastien Godard (sysstat <at> orange.fr)
 */

#ifndef _VERSION_H
#define _VERSION_H

/* sysstat version number */
#define VERSION	"12.0.1"

#endif  /* _VERSION_H */
