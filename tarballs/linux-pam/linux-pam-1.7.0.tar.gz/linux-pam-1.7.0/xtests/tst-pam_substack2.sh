#!/bin/sh

exec ./tst-pam_authsucceed tst-pam_substack2
