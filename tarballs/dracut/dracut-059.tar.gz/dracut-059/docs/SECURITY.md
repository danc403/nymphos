Security is very important to us. If you discover any issue regarding security, we'd appreciate a non-public disclosure of
the information, so  please disclose the information responsibly by sending an email to Harald Hoyer <harald@profian.com> and not by creating a GitHub issue. 
We will respond swiftly to fix verifiable security issues with the disclosure being coordinated with distributions and relevant security teams.
