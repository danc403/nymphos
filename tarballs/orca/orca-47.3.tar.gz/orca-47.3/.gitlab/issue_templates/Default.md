## Orca Version
*Note that versions prior to version 45.x are unsupported for non-critical issues.*

* Version of Orca where the bug is present
* If known, version of Orca where the bug is not present

## Steps to Reproduce the Problem
1. Step 1
2. Step 2
3. Step 3

## Expected Behavior
Describe what you expect to happen

## Actual Behavior
Describe what actually happens
