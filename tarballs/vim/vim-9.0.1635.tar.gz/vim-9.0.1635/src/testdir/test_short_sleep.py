#!/usr/bin/python
#
# Program that sleeps for 100 msec
#
# This requires Python 2.6 or later.

import time

if __name__ == "__main__":

    time.sleep(0.1)  # sleep 100 msec
