/*
** debug.h for eutp in /home/obert01/work/eutp/src
**
** Made by Olivier BERT
** Login   <obert01@epita.fr>
**
** Started on  Wed Mar 30 12:53:37 2005 Olivier BERT
** Last update Wed Mar 30 12:59:16 2005 Olivier BERT
*/
#ifndef __EUTP_DEBUG_H_
#define __EUTP_DEBUG_H_

int		debug_print_buf(unsigned char* buf);
#endif
