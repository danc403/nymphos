/*
** tools.h for eutp in /home/obert01/work/eutp/src
**
** Made by
** Login   <obert01@epita.fr>
**
** Started on  Thu Mar 31 12:36:55 2005
** Last update Fri Mar 24 17:31:41 2006 Olivier BERT
*/

#ifndef __EUTP_TOOLS_H_
#define __EUTP_TOOLS_H_
void		remove_blanks(unsigned char *str);
void		pad_blanks(unsigned char* str);

/* Display a lasting message */
void			brl_lasting_message(char* msg);

#endif
