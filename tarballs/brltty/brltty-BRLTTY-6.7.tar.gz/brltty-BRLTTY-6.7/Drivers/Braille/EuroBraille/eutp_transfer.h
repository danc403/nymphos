/*
** transfer.h for eutp in /home/obert01/work/eutp/src
**
** Made by Olivier BERT
** Login   <obert01@epita.fr>
**
** Started on  Sun Mar 20 16:10:12 2005 Olivier BERT
** Last update Thu May 26 14:10:18 2005 
*/

#ifndef __EUTP_TRANSFER_H_
#define __EUTP_TRANSFER_H_

int		brtopc(t_env*);
int		pctobr(t_env*);

#endif
