/*
** static.h for eutp in /home/obert01/work/eutp/src
**
** Made by
** Login   <obert01@epita.fr>
**
** Started on  Wed Jun  8 19:16:39 2005
** Last update Wed Jun  8 19:19:57 2005 
*/

#ifndef __EUTP_STATIC_H_
#define __EUTP_STATIC_H_
static unsigned char extensions[] = {'K', 'L', 'B', 'T', 'A'};
static unsigned char positions[] = {3, 7, 16};

#endif
