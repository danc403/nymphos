.. _BRLTTY on Android: Android.html
.. _Attributes Tables: AttributesTables.html
.. _Bluetooth Connections: Bluetooth.html
.. _Braille Dots: BrailleDots.html
.. _The Command Reference: CommandReference.html
.. _Contraction Tables: ContractionTables.html
.. _Local Customization: Customize.html
.. _Device Identifiers: Devices.html
.. _BRLTTY on DOS: DOS.html
.. _Introduction to BRLTTY: Introduction.html
.. _Key Tables: KeyTables.html
.. _BRLTTY on Linux: Linux.html
.. _BRLTTY on OpenBSD: OpenBSD.html
.. _Polling: Polling.html
.. _Privacy Policy: PrivacyPolicy.html
.. _Profiles: Profiles.html
.. _Using the Stow Build Manager: Stow.html
.. _Using Systemd Service Management: Systemd.html
.. _Text Tables: TextTables.html
.. _Using Upstart Service Management: Upstart.html
.. _BRLTTY on Windows: Windows.html
.. _BRLTTY with X11: X11.html

.. _BRLTTY's Web Site: https://brltty.app/
.. _The Android SDK Web Page: https://developer.android.com/sdk/index.html
.. _The Android NDK Web Page: https://developer.android.com/tools/sdk/ndk/index.html
