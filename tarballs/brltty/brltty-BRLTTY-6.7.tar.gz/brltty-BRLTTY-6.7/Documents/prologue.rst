.. include:: references.rst
.. include:: substitutions.rst
.. contents::
