``-v`` (verbose)
   Increase output verbosity. This option complements the ``-q`` option. It may
   be specified multiple times.

``-q`` (quiet)
   Decrease output verbosity. This option complements the ``-v`` option. It may
   be specified multiple times.

``-h`` (help)
   Write a brief command line usage summary on standard output, and then exit.

