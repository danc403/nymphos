.. |README.Android| replace:: `BRLTTY on Android`_
.. |README.AttributesTables| replace:: `Attributes Tables`_
.. |README.Bluetooth| replace:: `Bluetooth Connections`_
.. |README.BrailleDots| replace:: `Braille Dots`_
.. |README.CommandReference| replace:: `The Command Reference`_
.. |README.ContractionTables| replace:: `Contraction Tables`_
.. |README.Customize| replace:: `Local Customization`_
.. |README.Devices| replace:: `Device Identifiers`_
.. |README.DOS| replace:: `BRLTTY on DOS`_
.. |README.Introduction| replace:: `Introduction to BRLTTY`_
.. |README.KeyTables| replace:: `Key Tables`_
.. |README.Linux| replace:: `BRLTTY on Linux`_
.. |README.OpenBSD| replace:: `BRLTTY on OpenBSD`_
.. |README.Polling| replace:: `Polling`_
.. |README.PrivacyPolicy| replace:: `Privacy Policy`_
.. |README.Profiles| replace:: `Profiles`_
.. |README.Stow| replace:: `Using the Stow Build Manager`_
.. |README.Systemd| replace:: `Using Systemd Service Management`_
.. |README.TextTables| replace:: `Text Tables`_
.. |README.Upstart| replace:: `Using Upstart Service Management`_
.. |README.Windows| replace:: `BRLTTY on Windows`_
.. |README.X11| replace:: `BRLTTY with X11`_
