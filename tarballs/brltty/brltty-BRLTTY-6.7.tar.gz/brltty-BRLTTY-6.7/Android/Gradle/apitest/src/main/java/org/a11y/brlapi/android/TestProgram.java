package org.a11y.brlapi.android;

import org.a11y.brlapi.Connection;

public class TestProgram {
  public static void main (String[] arguments) {
  }
}
